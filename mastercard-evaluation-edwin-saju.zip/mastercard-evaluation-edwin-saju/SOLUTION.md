# Assumptions & Thoughts

## General Assumption

`Binrange.class` has a comparable implementation which is used to aid sort & search inside TreeMap which is used to store `BinRange` & associated `UUID`.
This  comparable implementation helps to keep the index unchanged for sub-ranges 

I assume all the ranges mentioned in the assignment is inclusive ranges

## Part 1

 What I notice the test case states `BinRangeInfo.class` after updating the cache for `BinRange` the test was only expecting latest values present in cache
So I think when ever the cache is loaded from file or external sources the index should be cleared . Wrote `clearCacheAndIndices` to achieve this  

## Part 2

In part 2 the description\required is not cleared in many places, 

### Assumptions

- User is only allowed to update sub-ranges `BinRangeInfo` no other properties can't be modified. 
- `UUID` is generated on server side while using REST endpoints , but when it's populated using external sources (files), UUID information is already available in file
 

### Parts that are not cleared , assumption made for that

- Requirement does not specify does the sub range should have different UUID, but looking on the  `comparable` implementation I assume the sub range should be part of `BinRangeInfo` or persist separate against associated `UUID` 
ie, `UUID` can one to many mapping against wider range & it's sub-range


- it's not clear while a sub-BinRange is added , then what should search with `PAN` return in response the entire `BinRangeInfo` with sub ranges or `BinRangeInfo` with sub-range details only or `BinRangeInfo` with entire range details .
 I assume it should return subrange information not entire one
 
- it's not clear about how deep the sub-range can got. I assume there is sno limit in real world. to support nested subrange some criteria should be in place

- it's not clear is there a possibility of overlapping ranges , I assume not.

### Thoughts

- Since all ranges are inclusive, and part to say `START` & `END`  should not be shared it's assumed, one ranges `START` can't be another range `END`

- We can use both `POST` and `PUT` to create resource. But I choose to use `POST` to create and `PUT` to update.
There are few exception made for POST request from idempotency POV to avoid duplicates , ie API block user from creating duplicates of `BinRangeInfo`

- Similarly we can use `PUT` & `PATCH` to update the resource , I prefer to choose `PATCH` since user is not allowed to  alter entire `BinRangeInfo`

- I choose `DELETE` to remove `BinRangeInfo`

- Chose to use `Range` from `Guava` library to store sub ranges. We can use `BinRange` also for this but need to write few apis around the class to make it fit for Purpose.  

## Part 3
